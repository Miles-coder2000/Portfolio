---
name: Bug Report 2
about: 'A Simple template to report the bug for small bug or normal problem '
title: ''
labels: bug
assignees: ''

---

Describe about your problem/bug ...


Provide few details about your device(like Android version) , Plugin version.

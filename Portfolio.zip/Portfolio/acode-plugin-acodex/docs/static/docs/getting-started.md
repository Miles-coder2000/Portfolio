# Getting Started with AcodeX

Welcome to AcodeX, the powerful terminal integration for your code editor!

## Installation

1. Open your code editor's marketplace
2. Search for "AcodeX"
3. Click "Install"
4. Restart your editor

## Basic Usage

To open the integrated terminal:

- Use the keyboard shortcut: `Ctrl+K`
- Or search for "Open Terminal" in the command palette

## Customization

You can customize AcodeX in the settings:

1. Open the settings panel
2. Navigate to the "AcodeX" section
3. Adjust the settings to your liking

Enjoy using AcodeX!

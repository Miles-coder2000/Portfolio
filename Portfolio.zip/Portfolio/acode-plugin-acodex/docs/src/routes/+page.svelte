<script lang="ts">
	import { Hero, Features, Docs } from '../components';
</script>

<main class="min-h-screen bg-gradient-to-b from-gray-900 to-black">
	<Hero />
	<Features />
	<Docs />
</main>

<section id="docs" class="py-20">
	<div class="container mx-auto px-4">
		<h2 class="text-4xl font-bold mb-12 text-center gradient-text">Documentation</h2>
		<div class="grid grid-cols-1 md:grid-cols-2 gap-8">
			<div
				class="bg-gray-800 bg-opacity-50 backdrop-blur-lg p-8 rounded-lg border-2 border-transparent moving-border"
			>
				<h3 class="text-2xl font-semibold mb-6 gradient-text">Quick Start</h3>
				<ol class="list-decimal list-inside space-y-4 text-gray-300">
					<li>Install AcodeX from your code editor's marketplace</li>
					<li>Open the AcodeX settings and configure your preferences</li>
					<li>Use the keyboard shortcut (default: Ctrl+k) to open the integrated terminal</li>
					<li>Start coding with enhanced terminal capabilities!</li>
				</ol>
			</div>
			<div
				class="bg-gray-800 bg-opacity-50 backdrop-blur-lg p-8 rounded-lg border-2 border-transparent moving-border"
			>
				<h3 class="text-2xl font-semibold mb-6 gradient-text">Acknowledgments</h3>
				<ul class="space-y-4 text-gray-300">
					<li>
						<strong class="text-accent">xtermjs:</strong> Terminal frontend used in AcodeX
					</li>
					<li>
						<strong class="text-accent">Termux:</strong> Terminal backend for AcodeX
					</li>
					<li>
						<strong class="text-accent">noVnc:</strong> Used in running gui apps
					</li>
				</ul>
			</div>
			<div
				class="bg-gray-800 bg-opacity-50 backdrop-blur-lg p-8 rounded-lg border-2 border-transparent moving-border"
			>
				<h3 class="text-2xl font-semibold mb-6 gradient-text">Support Project</h3>
				<ul class="space-y-4 text-gray-300">
					<li>
						<a href="https://www.buymeacoffee.com/bajrangCoder" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/v2/default-yellow.png" alt="Buy Me A Coffee" height="40" width="170"/></a>
					</li>
					<li>
					  <a href='https://ko-fi.com/M4M3QPI7K' target='_blank'><img height='36' style='border:0px;height:36px;' src='https://storage.ko-fi.com/cdn/kofi1.png?v=3' border='0' alt='Buy Me a Coffee at ko-fi.com' /></a>
					</li>
				</ul>
			</div>
		</div>
		<div class="text-center mt-12">
			<a
				href="/docs"
				class="inline-block bg-secondary hover:bg-secondary/80 text-white font-bold py-3 px-8 rounded-full transition duration-300"
			>
				Read Full Documentation
			</a>
		</div>
	</div>
</section>

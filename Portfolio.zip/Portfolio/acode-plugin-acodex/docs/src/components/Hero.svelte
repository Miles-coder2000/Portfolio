<script lang="ts">
	const version = 'v3.1.8';
</script>

<section class="py-20">
	<div class="container mx-auto px-4 text-center">
		<div class="inline-block mb-6">
			<div
				class="bg-gray-800 bg-opacity-50 backdrop-blur-lg py-1 px-3 rounded-full text-sm font-medium text-accent border border-accent animate-pulse-slow"
			>
				{version}
			</div>
		</div>
		<h2 class="text-5xl sm:text-6xl font-extrabold mb-6">
			<span class="gradient-text">Supercharge</span> Your Code Editor
		</h2>
		<p class="text-xl mb-8 text-gray-400 max-w-2xl mx-auto">
			AcodeX brings powerful terminal integration for seamless development, right where you need it.
		</p>
		<a
			href="/"
			class="bg-primary hover:bg-primary/80 text-white font-bold py-3 px-8 rounded-full transition duration-300 inline-block glow"
		>
			Get Started
		</a>
	</div>
</section>

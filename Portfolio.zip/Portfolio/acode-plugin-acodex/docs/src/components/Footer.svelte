<footer class="bg-gray-800 py-4">
	<div class="container mx-auto px-4 text-center text-gray-400">
		<p>&copy; 2024 AcodeX. All rights reserved.</p>
	</div>
</footer>

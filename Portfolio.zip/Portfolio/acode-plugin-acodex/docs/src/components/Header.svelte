<header class="py-6 header-blur sticky top-0 z-50">
	<div class="container mx-auto px-4 flex justify-between items-center">
		<h1 class="text-3xl font-bold gradient-text">AcodeX</h1>
		<nav>
			<ul class="flex space-x-6">
				<li><a href="/#features" class="text-gray-300 hover:text-white transition">Features</a></li>
				<li><a href="/docs" class="text-gray-300 hover:text-white transition">Docs</a></li>
			</ul>
		</nav>
	</div>
</header>
